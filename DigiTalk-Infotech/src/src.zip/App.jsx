import lavablock from "./components/lavablock";
import leftcentre from "./components/hero";
import nav from "./components/nav";
import Options from "./components/options";
import steps from "./components/steps";


const App = () => {
  
  return (
    <>
    {lavablock()}
    {nav()}
    {leftcentre()}
    {Options()}
    {steps()}
    </>
  );
};

export default App;